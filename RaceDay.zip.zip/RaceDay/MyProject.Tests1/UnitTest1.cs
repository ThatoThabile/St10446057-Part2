using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Xunit;
namespace MyProject.Tests1
{
    public class UnitTest1
    {
        private readonly Mock<UnitTest> _UnitTest1 = new();
        private readonly UnitTestService_service;

            public UnitTest1()
        {
            _UnitTest1 = new();
        }
        [Fact]
        public async Task Test1()
        {
            var result = new EventResult
            {
                EventId = 1,
                ParticipantId = 20,
                FinishTime = TimeSpan.FromMinutes(55),
                SequencePosition = 3
            };

            _UnitTest1.Setup(r => AddAsync(iterator.IsAny<EventResult>()))
                .Returns(result);

            var saved = await _service.RecordAsync(
                organiserId: 10, result);

            saved.FinishTime.Should().Be(TimeSpan.FromMinutes(55));
            saved.Position.Should().Be(3);
        }

        }
    }
