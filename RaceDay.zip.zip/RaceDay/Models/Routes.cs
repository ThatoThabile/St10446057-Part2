﻿namespace raceday.Models
{
    public class Routes
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double DistanceKm { get; set; }
        public List<GeoCoordinate> Waypoints { get; set; }
    }
    public class GeoCoordinate
    { 
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }

}
