﻿using System;
using System.ComponentModel.DataAnnotations;
namespace raceday.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        [StringLength (50)]
        public string Name { get; set; }=string.Empty;

        [Required]
        [StringLength(50)]
        public string Email { get; set; }=string.Empty;

        [Required]
        [StringLength (50)]
        public string Password { get; set; }
        = string.Empty;

        [Required]
        [StringLength (50)]
        public string PhoneNumber { get; set; }
= string.Empty;

        [StringLength(20)]
        public string Category { get; set; } = "Open";
    }
}
